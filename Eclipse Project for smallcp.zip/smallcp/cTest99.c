
#include "stdio.h"
/*
char z;
int gi;
int gid;
int i;
int fd;
int a;
double dd;
double de;
double dt[50];
char str[128];
int wtr[128];
*/

main (argc,argv) int argc; char *argv[]; {

//	char *c;
//	char *fcb;
//	char *name;
//	char ch;
double a;
double b;
int c;
char str[32];

//	double b;
//	double d;
//	puts("HELLO WORLD");
//#asm
//	B @80H ;go to shell
//#endasm
/*
	a = 12.6;
	b = 2.1;
	c = a - b;
	printf("\n2-1=%d\n",c);


	a = 4.8;
	b = 13.5;
	c = a - b;
	printf("\n4-3=%d\n",c);

	a = 4.6999;
	b = 125.9999;

	c = a + b;
	printf("\n4.2+5.9=%d\n",c);

	a = -12.0;
	b = 5.0;
	c = a - b;
	printf("\n-a-b=%d\n",c);


	a = 0.0;
	b = -5.0;
	c = a - b;
	printf("\n0--b=%d\n",c);



	a = -12.0;
	b = -5.0;
	c = a - b;
	printf("\n-a--b=%d\n",c);


	a= 12.99*2.40;
	c = a;
	a *= 10.0 ;
	c= a;
	*/
	a = 3.3;
	c = 1;
	ftoa2(a,c,str);
	puts(str);
	return;

/*
	printf("\nMultiplication test -> 12.99*2.4 = %d\n",c);

	a= 12.99/2.40;
	c = a;
	printf("\nDivision test -> 12.99/2.4 = %f\n",a);
	return;

 /*	itox(a,str,4);
 	puts(str);

	printf("\na = %d\n",a);

	a= 3.0 + 4.3;
	printf("\n3.0+4.3 = %d\n",a);

	a = -105.0+1.0+34.6;
	printf("\n-105.0+1.0+34.6 = %d\n",a);

	a = 250.0/2.0;
	printf("\n250.0/2.0 = %d\n",a);

	a = 126.0*122.0;
	printf("\n126.0*122.0 = %d\n",a);
/*
	dd = 1.0 * 2.0;
	printf("\na = %d\n",dd);

	dd = 1.0 * 2.0;

	printf("\ndd = %f\n",dd);

	a = -2.0;
	printf("\nThe floating point number converted to integer is %d\n",a);
	a = 2.0;
	printf("\nThe floating point number converted to integer is %d\n",a);
	a = 28598e23;
	printf("\nThe floating point number converted to integer is %d\n",a);
	a = 28598e-23;
	printf("\nThe floating point number converted to integer is %d\n",a);


	printf("The floating point number is %f\n",a);
	b= -2.0;
	d=  0.0;
	a = a + b;
	printf("result = %f",a);
		name = "hello";
	z= ch;
	ch = z;

	puts("Hello World\N");

   printf("%d\n",argc);
	    for(i=1;i< argc;i++)
	    {
	        printf("%s%c",argv[i],(i<argc-1) ? ' ' : '\n');
	    }


    ch = 'c';

	printf("Character is %c%s \n", ch,"hello\n");

	fd = fopen("JUNK1","w");
	printf ("open for writing fd = %d",fd);
	ch = putc('d',fd);
	fclose(fd);

	fd = fopen("JUNK1","r");
	printf ("reading fd = %d",fd);
	ch = getc(fd);
	printf ("char  = %c",ch);
	fclose(fd);

*/

}

/* convert double number to string (f format) */

ftoa2(x,f,str)
double x;	/* the number to be converted */
int f;		/* number of digits to follow decimal point */
char *str;	/* output string */
{

	int a;
	double scale;		/* scale factor */

	int i,				/* copy of f, and # digits before decimal point */
		d;				/* a digit */


	if(x  < 0.0 ) {

	}


/*
	while ( i-- )
		scale *= 10.0 ;

	x += 1.0 / scale ;

	i = 0 ;
	scale = 1.0 ;


	while ( x >= scale ) {
		scale *= 10.0 ;
		i++ ;
	}

	while ( i-- ) {

		scale = _floor(0.5 + scale * 0.1 ) ;
		d = ifix( x / scale ) ;
		*str++ = d + '0' ;
		x -= float(d) * scale ;
	}

	if ( f <= 0 ) {
		*str = NULL ;
		return ;
	}
	*str++ = '.' ;
	while ( f-- ) {

		x *= 10.0 ;
		d = ifix(x) ;
		*str++ = d + '0' ;
		x -= float(d) ;
	}
	*str = NULL ;
*/
}

upper(c, ch) int c; char ch; {
	c = ch;
	return c;

}

